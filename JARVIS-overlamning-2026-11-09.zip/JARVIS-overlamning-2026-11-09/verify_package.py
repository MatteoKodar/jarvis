"""Read-only integrity check. Run with Python 3 from any working directory."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
manifest_path = root / 'PACKAGE-MANIFEST.json'
if not manifest_path.is_file():
    raise SystemExit('PACKAGE-MANIFEST.json is missing; the package is incomplete.')
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
problems = []
for name, record in manifest['files'].items():
    relative = Path(name)
    path = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(root):
        problems.append('Unsafe manifest path: ' + name)
        continue
    if not path.is_file():
        problems.append('Missing: ' + name)
        continue
    data = path.read_bytes()
    if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
        problems.append('Changed: ' + name)
for message in problems:
    print(message)
if problems:
    raise SystemExit(1)
print(f"OK: {len(manifest['files'])} packaged files match their SHA256 and size.")
print('Integrity only: this does not execute product tests or prove external authenticity.')
sys.exit(0)
