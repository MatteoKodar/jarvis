"""Run an explicitly requested Claude text review with no tools or project access."""
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

prompt_file = Path(sys.argv[1]).resolve()
prefix = Path(sys.argv[2]).resolve()
prefix.parent.mkdir(parents=True, exist_ok=True)
args = [r'C:\Users\matte\.local\bin\claude.exe', '--print', '--safe-mode',
        '--restricted', '--strict-mcp-config', '--tools', '',
        '--disable-slash-commands', '--permission-mode', 'dontAsk',
        '--no-session-persistence', '--output-format', 'json']
try:
    result = subprocess.run(args, input=prompt_file.read_text(encoding='utf-8'),
        text=True, encoding='utf-8', capture_output=True,
        cwd=Path(__file__).resolve().parent, timeout=600)
except subprocess.TimeoutExpired:
    prefix.with_suffix('.exit.txt').write_text('timeout', encoding='utf-8')
    raise
prefix.with_suffix('.json').write_text(result.stdout, encoding='utf-8')
prefix.with_suffix('.stderr.txt').write_text(result.stderr, encoding='utf-8')
prefix.with_suffix('.exit.txt').write_text(str(result.returncode), encoding='utf-8')
if result.returncode:
    print(result.stderr[-2000:])
    print(result.stdout[-2000:])
    raise SystemExit(result.returncode)
reply = json.loads(result.stdout)
if reply.get('is_error'):
    print(reply.get('result', 'Claude returned error'))
    raise SystemExit(1)
answer = reply.get('result')
assert isinstance(answer, str) and answer.strip(), 'Empty Claude reply'
prefix.with_suffix('.txt').write_text(answer, encoding='utf-8')
print(answer)
