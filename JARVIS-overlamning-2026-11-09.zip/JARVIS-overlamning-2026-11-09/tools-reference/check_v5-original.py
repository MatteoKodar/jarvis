"""Run bounded checks in the isolated snapshot and record source/exit evidence."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
BASE=Path(r'C:\Users\matte\Documents\Codex\2026-11-06\jkag-x20')
OUT=BASE/'outputs/ai-kedja-v5';STAGE=BASE/'work/ai-kedja-v5/source'
label,kind,*args=sys.argv[1:]
assert label.replace('-','').replace('_','').isalnum()
assert not (OUT/(label+'.exit.txt')).exists(),'Use a fresh log name'
new=['backend/jarvis/paper_data.py','backend/jarvis/paper_review.py','backend/jarvis/paper_evaluation.py',
 'tests/test_paper_data.py','tests/test_paper_review.py','tests/test_paper_evaluation.py','tests/test_paper_api.py',
 'tests/fixtures/paper_input_v1.json','tests/fixtures/paper_results_v1.json',
 'frontend/src/PaperReplay.tsx','frontend/e2e/paper-replay.spec.ts']
names=set(json.loads((OUT/'source-baseline.json').read_text(encoding='utf-8'))['sha256'])|set(new)
def version():return {n:hashlib.sha256((STAGE/n).read_bytes()).hexdigest() for n in sorted(names) if (STAGE/n).is_file()}
before=version();(OUT/(label+'.version.json')).write_text(json.dumps(before,indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('OPENAI_API_KEY',None)
env.update(PYTHONPATH=str(STAGE/'backend'),JARVIS_PAID_ENABLED='false',JARVIS_RESEARCH_ENABLED='false',
 JARVIS_PYTHON=r'C:\Users\matte\jarvis\.venv\Scripts\python.exe',
 PLAYWRIGHT_BROWSERS_PATH=r'C:\Users\matte\OneDrive\Dokument\ChatGPT\Jarvis odds\work\demo-guide\data\browsers',
 JARVIS_REVIEW_EVIDENCE_DIR=str(OUT),PWTEST_CACHE_DIR=str(BASE/'work/ai-kedja-v5'/('cache-'+label)),PYTHONIOENCODING='utf-8')
python=r'C:\Users\matte\jarvis\.venv\Scripts\python.exe';node=shutil.which('node.exe');assert node
if kind=='pytest':cmds=[[python,'-m','pytest','-q',*args]];cwd=STAGE
elif kind=='build':cmds=[[node,r'.\node_modules\typescript\bin\tsc','-b'],[node,r'.\node_modules\vite\bin\vite.js','build']];cwd=STAGE/'frontend'
elif kind=='e2e':cmds=[[node,r'.\node_modules\@playwright\test\cli.js','test','--reporter=line',*args]];cwd=STAGE/'frontend'
else:raise SystemExit('unknown check')
assert not (STAGE/'.env').exists()
exitcode=0;executed=[]
with (OUT/(label+'.txt')).open('w',encoding='utf-8') as log:
 for cmd in cmds:
  log.write('COMMAND '+json.dumps(cmd)+'\n');log.flush()
  result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
  executed.append({'command':cmd,'exit':result.returncode})
  if result.returncode:exitcode=result.returncode;break
after=version();changed=[n for n in before if before[n]!=after.get(n)]
assert all(n.endswith('.png') for n in changed),'Source changed during checks: '+str(changed)
(OUT/(label+'.exit.txt')).write_text(str(exitcode),encoding='utf-8')
(OUT/(label+'.commands.json')).write_text(json.dumps({'executed':executed,'source_unchanged':True,'generated_screenshots':changed},indent=2),encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8');print((OUT/(label+'.txt')).read_text(encoding='utf-8')[-5000:]);sys.exit(exitcode)
